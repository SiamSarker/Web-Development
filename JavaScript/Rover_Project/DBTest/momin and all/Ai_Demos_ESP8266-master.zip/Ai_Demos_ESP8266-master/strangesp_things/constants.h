#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_
#include <Arduino.h>
namespace constants
{
  extern const char webpage[];
  extern const char* ssid;
  extern const char* password;
}

#endif
